package com.me.mygdxgame;

import java.util.concurrent.TimeUnit;

import com.badlogic.gdx.ApplicationListener;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL10;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.Texture.TextureFilter;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.utils.TimeUtils;

public class RepeatedBackground implements ApplicationListener {
	private OrthographicCamera camera;
	private SpriteBatch batch;
	private Texture background;
	private Texture bucketImage;
	
	private float currentBgX;
	private float currentBucketY;
	private long lastTimeBg;
	
	@Override
	public void create() {		
		
		camera = new OrthographicCamera();
		camera.setToOrtho(false, 800, 480);
		batch = new SpriteBatch();
		
		background = new Texture(Gdx.files.internal("bg.jpg"));
		currentBgX = 800;
		currentBucketY = 20;
		lastTimeBg = TimeUtils.nanoTime();
		
		bucketImage = new Texture(Gdx.files.internal("bucket.png"));
		
	}

	@Override
	public void dispose() {
		batch.dispose();
		background.dispose();
	}

	@Override
	public void render() {		
		Gdx.gl.glClearColor(1, 1, 1, 1);
		Gdx.gl.glClear(GL10.GL_COLOR_BUFFER_BIT);
		
		batch.setProjectionMatrix(camera.combined);
		batch.begin();
		batch.draw(background, currentBgX - 800, 0);
		batch.draw(background, currentBgX, 0);
//		batch.draw(bucketImage, 20, currentBucketY);
		batch.end();
		
		if(TimeUtils.nanoTime() - lastTimeBg > 100000000){
			currentBgX -= 50;
			lastTimeBg = TimeUtils.nanoTime();
//			if(currentBucketY == 20)
//				currentBucketY += 10;
//			else
//				currentBucketY -= 10;
		}
		
		if(currentBgX == 0){
			currentBgX = 800;
		}
	}

	@Override
	public void resize(int width, int height) {
	}

	@Override
	public void pause() {
	}

	@Override
	public void resume() {
	}
}
